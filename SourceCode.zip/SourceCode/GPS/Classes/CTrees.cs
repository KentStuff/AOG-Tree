﻿using System;
using System.Collections.Generic;
using System.Linq;
using OpenTK.Graphics.OpenGL;
using System;
using System.Collections.Generic;

namespace AgOpenGPS
{
    public class CTreePt
    {
        private readonly FormGPS mf;
        public double altitude { get; set; }
        public double easting { get; set; }
        public double northing { get; set; }
        public double heading { get; set; }
        public double cutAltitude { get; set; }
        public double lastPassAltitude { get; set; }
        public double latitude { get; set; }
        public double longitude { get; set; }
        public double distance { get; set; }
        
        public bool isPlanted = false;
        public bool isclose = false;
        public bool isReference = false;
        public bool isSelected = false;
        public bool istrolling = false;
        
        

        public int index = 0;
        public string comment;

        //constructor
        public CTreePt(FormGPS _f)
        {
            mf = _f;
            //if (mf != null)
            //{
            //    gl = _gl;
            //}
        }
        public CTreePt(double _easting, double _heading, double _northing, double _lat, double _long)
        {
            easting = _easting;
            northing = _northing;
            heading = _heading;
            
            //optional parameters
           
            isPlanted = false;
            isclose = false;
            isReference = false;
            comment = "Tree";
            isSelected = false;
            


            
            latitude = _lat;
            longitude = _long;

            index = 0;

        }
    }

    public class CTree
    {
        //copy of the mainform address
        //constructor



        //pointers to mainform controls
        private readonly FormGPS mf;

        //private readonly OpenGL gl;

        public bool isTreeOn = false;
        public bool isTreeBtnOn;
        public bool isShowCut = false;
        public bool isShowProposed = false;
        public bool istrolling = false;
        public bool isHoldBoundary = true;
        public bool hasBeenBuilt = false;
        public bool isDrawTreePts = true;
        public bool foundit = false;
        public int click = 0;
        public int whenself = 0;
        public int treeCols = 1;
        public int treeRows = 1;
        public double treeXSpace = 1000;
        public double treeYSpace = 1000;
        public double closeDistance = 0;
        public double lastCloseDistance = 0;
        public double treeDelta = 0;
        public double slope = 0.002;
        public vec2 treeA;
        public vec2 treeB;
        public bool isAPicked = false;
        public bool isBPicked = false;
        public bool autoPlant = true;
        public bool isOK2Plant = true;
        public double treeABHeading = 0;
        public double conv = 0;

        public double cosSectionHeading = 1.0, sinSectionHeading = 0.0;
        public double cosSectionHeading90 = -1.0, sinSectionHeading90 = 0.0;








        public List<CTreePt> ptList = new List<CTreePt>();
        public List<CTreePt> ptListOriginal = new List<CTreePt>();





        //used to determine if section was off and now is on or vice versa
        public bool wasSectionOn;
        public bool isContourBtnOn = true;

       
       
        
     
        public List<vec2> drawList = new List<vec2>();

        

        //constructor
        public CTree(FormGPS _f)
        {
            mf = _f;
            //if (mf != null)
            //{
            //    gl = _gl;
            //}
        }

        

        //Add current position to ptList
        public void AddPoint(double _easting,double _northing)
        {
            double east = _easting;
            double nort = _northing;

            //fix the azimuth error
            double eastingTemp = (Math.Cos(mf.pn.convergenceAngle) * east) - (Math.Sin(mf.pn.convergenceAngle) * nort);
            double northingTemp = (Math.Sin(mf.pn.convergenceAngle) * east) + (Math.Cos(mf.pn.convergenceAngle) * nort);

            eastingTemp += mf.pn.utmEast;
            northingTemp += mf.pn.utmNorth;

            mf.UTMToLatLon(eastingTemp, northingTemp);

            double latitude = mf.utmLat;
            double longitude = mf.utmLon;

            CTreePt point = new CTreePt(_easting,0, _northing,latitude,longitude);
            ptList.Add(point);
            ptListOriginal.Add(point);
            ptList[ptList.Count - 1].index = ptList.Count;
        }

       

        public void BuildOrchard(vec2 _orgin,double _maxDistance, double _theta)
        {
            double Currentx = treeA.easting;
            double Currenty = treeA.northing;
            double offsetx = treeXSpace;
            double offsety = treeYSpace;
            int numberOfPoints = 0;
            double delta = (_maxDistance / 2)+50000;
            int deltaX =(int)(delta / treeXSpace);
            int deltaY = (int)(delta / treeXSpace);
            if (autoPlant)
            {
                treeA = _orgin;
                for (int x = -deltaX; x < deltaX*2; x++)
                {

                    for (int y = -deltaY; y < deltaY*2; y++)
                    {

                        Currentx = treeA.easting + (x * treeXSpace / 100);
                        Currenty = treeA.northing + (y * treeYSpace / 100);
                        vec2 pnt = new vec2();
                        pnt.easting = Currentx;
                        pnt.northing = Currenty;
                        pnt = RotatePoint(pnt, treeA, _theta);
                        if (mf.gf.IsPointInsideGeoFences(pnt))
                        {
                            AddPoint(pnt.easting, pnt.northing);
                            ptList[numberOfPoints].heading = ConvertToRadians(_theta);
                            numberOfPoints++;


                        }

                    }

                }
            }
            else
            {
                for (int x = -0; x < treeCols; x++)
                {

                    for (int y = -0; y < treeRows; y++)
                    {

                        Currentx = treeA.easting + (x * treeXSpace / 100);
                        Currenty = treeA.northing + (y * treeYSpace / 100);
                        vec2 pnt = new vec2();
                        pnt.easting = Currentx;
                        pnt.northing = Currenty;
                        pnt = RotatePoint(pnt, treeA, _theta);
                        if (mf.gf.IsPointInsideGeoFences(pnt))
                        {
                            AddPoint(pnt.easting, pnt.northing);
                            ptList[numberOfPoints].heading = ConvertToRadians(_theta);
                            numberOfPoints++;


                        }

                    }

                }
            }
        }

        public void RotateOrchard(double _theta, vec2 _orgin)
        {
            vec2 pnt = new vec2();
            int ptCount = ptList.Count - 1;
            for (int t = 0; t < ptCount; t++)
            {
                pnt.easting = ptList[t].easting;
                pnt.northing = ptList[t].northing;
                pnt= RotatePoint(pnt, _orgin, _theta);
                ptList[t].easting = pnt.easting;
                ptList[t].northing = pnt.northing;
            }
            mf.FileSaveTree();


         }

       
        

        public int GetTreePt(double _easting, double _northing, List<CTreePt> _ptList)
        {
            int alfa = 0;
            int ptCount = _ptList.Count - 1;
            for (int t = 0; t < ptCount; t++)
            {

                if (_ptList[t].easting == _easting && _ptList[t].northing == _northing)
                {
                    alfa = t;
                    return alfa;
                }

            }
            return alfa;

        }

        public void NoClosePoints(List<CTreePt> _ptList)
        {
            int ptCnt = _ptList.Count;

            if (ptCnt > 0)
            {

                int ptCount = _ptList.Count - 1;
                for (int t = 0; t < ptCount; t++)
                {
                    _ptList[t].isclose = false;

                }
            }
        }

        public void UnSelectAllPoints(List<CTreePt> _ptList)
        {
            int ptCnt = _ptList.Count;

            if (ptCnt > 0)
            {

                int ptCount = _ptList.Count - 1;
                for (int t = 0; t < ptCount; t++)
                {
                    _ptList[t].isSelected = false;

                }
            }
        }


        public int GetSelectedCount(List<CTreePt> _ptList)
        {
            int _SCount = 0;

            int ptCnt = _ptList.Count;

            if (ptCnt > 0)
            {

                int ptCount = _ptList.Count - 1;
                for (int t = 0; t < ptCount; t++)
                {
                    if (ptList[t].isSelected)
                    {

                        _SCount += 1;

                    }

                }
            }

            return _SCount;
        }

        public bool Plant(double _easting, double _northing, List<CTreePt> _ptList,double error)
        {
            bool yes = false;
            int cnt = _ptList.Count;

            if (cnt >0)
            {
                for (int t = 0; t < cnt-1; t++)
                {
                    if (_ptList[t].isclose)
                    {
                        double dist = ((_easting - _ptList[t].easting) * (_easting - _ptList[t].easting))
                                    + ((_northing - _ptList[t].northing) * (_northing - _ptList[t].northing));
                        dist = Math.Sqrt(dist);
                        if (dist < error) yes = true;
                    }
                }
                }
            return yes;
        }

        public int GetClosestTreePt(double _easting, double _northing, List<CTreePt> _ptList)
        {
            int cltPointA = 0;

            double minidistA = 1000000;
            int ptCnt = _ptList.Count;

            if (ptCnt > 0)
            {

                int ptCount = _ptList.Count - 1;
                for (int t = 0; t < ptCount; t++)
                {

                    double dist = ((_easting - _ptList[t].easting) * (_easting - _ptList[t].easting))
                                    + ((_northing - _ptList[t].northing) * (_northing - _ptList[t].northing));
                    if (dist < minidistA)
                    {

                        minidistA = dist; cltPointA = t;

                    }

                }

                cltPointA = GetTreePt(_ptList[cltPointA].easting, _ptList[cltPointA].northing, _ptList);
                lastCloseDistance = closeDistance;
                closeDistance = Math.Sqrt(minidistA);
                
               

                if (Math.Abs(lastCloseDistance) > closeDistance) closeDistance *= 1;
                else closeDistance *= -1;



            }

            return cltPointA;

        }

        public vec2 RotatePoint(vec2 p1, vec2 p2, double angle)
        {

            double radians = ConvertToRadians(angle);
            double sin = Math.Sin(radians);
            double cos = Math.Cos(radians);

            // Translate point back to origin
            p1.easting -= p2.easting;
            p1.northing -= p2.northing;

            // Rotate point
            double xnew = p1.easting * cos - p1.northing * sin;
            double ynew = p1.easting * sin + p1.northing * cos;

            // Translate point back
            vec2 newPoint = new vec2(xnew + p2.easting, ynew + p2.northing);
            return newPoint;
        }

        public double ConvertToRadians(double angle)
        {
            return (Math.PI / 180) * angle;
        }


        public double GetElevation(double _easting, double _northing, List<CTreePt> _ptList)
        {
            double rElevation = 0;
            int cltPointA = 0;
            int cltPointB = 0;
            int cltPointC = 0;
            int cltPointD = 0;

            double minidistA = 1000000;
            double minidistB = 1000000;
            double minidistC = 1000000;
            double minidistD = 1000000;

            int ptCnt = _ptList.Count;

            if (ptCnt > 0)
            {

                int ptCount = _ptList.Count - 1;
                for (int t = 0; t < ptCount; t++)
                {

                    double dist = ((_easting - _ptList[t].easting) * (_easting - _ptList[t].easting))
                                    + ((_northing - _ptList[t].northing) * (_northing - _ptList[t].northing));
                    if (dist < minidistA)
                    {

                        minidistA = dist; cltPointA = t;

                    }

                }
                for (int t = 0; t < ptCount; t++)
                {
                    double dist = ((_easting - _ptList[t].easting) * (_easting - +ptList[t].easting))
                                    + ((_northing - _ptList[t].northing) * (_northing - _ptList[t].northing));
                    if (dist < minidistB && t != cltPointA)
                    {

                        cltPointB = t;
                        minidistB = dist;

                    }

                }
                for (int t = 0; t < ptCount; t++)
                {
                    double dist = ((_easting - _ptList[t].easting) * (_easting - +ptList[t].easting))
                                    + ((_northing - _ptList[t].northing) * (_northing - _ptList[t].northing));
                    if (dist < minidistC && t != cltPointA && t != cltPointB)
                    {

                        cltPointC = t;
                        minidistC = dist;

                    }

                }
                for (int t = 0; t < ptCount; t++)
                {
                    double dist = ((_easting - _ptList[t].easting) * (_easting - +ptList[t].easting))
                                    + ((_northing - _ptList[t].northing) * (_northing - _ptList[t].northing));
                    if (dist < minidistD && t != cltPointA && t != cltPointB && t != cltPointC)
                    {

                        cltPointD = t;
                        minidistD = dist;

                    }

                }

                cltPointA = GetTreePt(_ptList[cltPointA].easting, _ptList[cltPointA].northing, _ptList);


                cltPointB = GetTreePt(_ptList[cltPointB].easting, _ptList[cltPointB].northing, _ptList);

                cltPointC = GetTreePt(_ptList[cltPointC].easting, _ptList[cltPointC].northing, _ptList);



                cltPointD = GetTreePt(_ptList[cltPointD].easting, _ptList[cltPointD].northing, _ptList);




                minidistA = Math.Sqrt(minidistA);
                minidistB = Math.Sqrt(minidistB);
                minidistC = Math.Sqrt(minidistC);
                minidistD = Math.Sqrt(minidistD);

                double currentAltitude = (_ptList[cltPointA].altitude);
                double toole = Properties.Vehicle.Default.setVehicle_toolWidth;
                if (minidistA <= toole / 2 | minidistB <= toole / 2 | minidistC <= toole / 2 | minidistD <= toole / 2)
                {
                    //if the blade is over the point just set the altitude to the point,
                    //gets rid of the division by zero error.
                    currentAltitude = (_ptList[cltPointA].altitude);
                }
                else
                {
                    //Weighted Average
                    double sumofmindist = 1 / minidistA + 1 / minidistB + 1 / minidistC + 1 / minidistD;
                    currentAltitude = (((_ptList[cltPointA].altitude / minidistA)) + ((_ptList[cltPointB].altitude / minidistB)) +
                        ((_ptList[cltPointC].altitude / minidistC)) + ((_ptList[cltPointD].altitude / minidistD))) / sumofmindist;
                }
                //Console.WriteLine(currentAltitude.ToString("N2"));
                rElevation = currentAltitude;


            }

            return rElevation;

        }

        private void DrawCircle(double radius)
        {
            //GL.Disable(EnableCap.Texture2D);


            GL.Enable(EnableCap.Blend);
            GL.Color4(.2f, .5f, .2f, 0.5f);
            double theta = 6.28 / 20;
            double c = Math.Cos(theta);//precalculate the sine and cosine
            double s = Math.Sin(theta);
            double x = 0;
            double y =0;
            GL.LineWidth(1);
            GL.Begin(PrimitiveType.TriangleFan);
            x += radius;
            GL.Vertex3(x, y, 0.0);

            for (int ii = 0; ii < 21; ii++)
            {
                //output vertex
                //GL.Vertex3(x, y, 0.0);

                //apply the rotation matrix
                double t = x;
                x = ((c * x) - (s * y));
                y = (s * t) + (c * y);
                GL.Vertex3(x, y, 0.0);
            }
            GL.End();

            GL.Color4(.2f, .9f, .2f, .2f);
            
            x =0;
            y =0;
            GL.LineWidth(2);
            GL.Begin(PrimitiveType.LineLoop);
            x += radius;
            GL.Vertex3(x, y, 0.0);

            for (int ii = 0; ii < 21; ii++)
            {
                //output vertex
                //GL.Vertex3(x, y, 0.0);

                //apply the rotation matrix
                double t = x;
                x = ((c * x) - (s * y));
                y = (s * t) + (c * y);
                GL.Vertex3(x, y, 0.0);
            }
            GL.End();




            

        }



        public void DrawTrees()
        {
            

            ////draw the guidance line
            int ptCount = ptList.Count;
            conv = mf.pn.convergenceAngle;


            //draw the reference line

            GL.LineWidth(1);
            if (isDrawTreePts)
            {

                ptCount = ptList.Count;
                if (ptCount > 0)
                {


                    double toole = Properties.Vehicle.Default.setVehicle_toolWidth/1.25;
                   

                    for (int i = 1; i < ptCount; i++)
                    {
                        
                            float green = Convert.ToSingle(256 / 256);
                            float red = Convert.ToSingle(256 / 256);
                            float blue = Convert.ToSingle(256 / 256);
                            sinSectionHeading = Math.Sin(ptList[i].heading);
                            cosSectionHeading = Math.Cos(ptList[i].heading);
                            sinSectionHeading90 = Math.Sin(-ptList[i].heading);
                            cosSectionHeading90 = Math.Cos(-ptList[i].heading);

                        if (ptList[i].isSelected) GL.LineWidth(3);
                            else GL.LineWidth(1);

                            GL.Color3(red, green, blue);
                            if (ptList[i].isclose)
                            {
                            GL.Color3(0,green,0);
                            GL.LineWidth(4);
                            }
                            GL.Begin(PrimitiveType.Lines);
                            GL.Vertex3((cosSectionHeading * -toole / 2) + ptList[i].easting,
                               (sinSectionHeading * -toole / 2) + ptList[i].northing, 0);
                            GL.Vertex3((cosSectionHeading * toole / 2) + ptList[i].easting,
                               (sinSectionHeading * toole / 2) + ptList[i].northing, 0);
                            GL.Vertex3((sinSectionHeading90 * -toole / 2) + ptList[i].easting,
                           (cosSectionHeading90 * -toole / 2) + ptList[i].northing, 0);
                            GL.Vertex3((sinSectionHeading90 * toole / 2) + ptList[i].easting,
                               (cosSectionHeading90 * toole / 2) + ptList[i].northing, 0);
                            GL.End();


                            if (istrolling)
                            {
                                if (i == whenself)
                                {
                                    GL.Color3(1f, 1f, 1f);
                                    GL.PointSize(10);
                                    GL.Begin(PrimitiveType.Points);
                                    GL.Vertex3(ptList[i].easting, ptList[i].northing, 0);
                                    GL.End();

                                    GL.Color3(0f, 0f, 1f);
                                    GL.PointSize(8);
                                    GL.Begin(PrimitiveType.Points);
                                    GL.Vertex3(ptList[i].easting, ptList[i].northing, 0);
                                    GL.End();
                                }
                            }

                            if (ptList[i].isReference)
                            {
                                GL.Color3(1f, 1f, 1f);
                                GL.PointSize(10);
                                GL.Begin(PrimitiveType.Points);
                                GL.Vertex3(ptList[i].easting, ptList[i].northing, 0);
                                GL.End();

                                GL.Color3(1f, 1f, 0f);
                                GL.PointSize(8);
                                GL.Begin(PrimitiveType.Points);
                                GL.Vertex3(ptList[i].easting, ptList[i].northing, 0);
                                GL.End();
                            }
                                                                                                          
                           

                            if (ptList[i].isclose)
                            {
                                red = .4F;
                                blue = 1;
                                green = .4F;
                                GL.PointSize(8);
                                GL.Color3(red, green, blue);
                                GL.Begin(PrimitiveType.Points);
                                GL.Vertex3(ptList[i].easting, ptList[i].northing, 0);
                                GL.End();
                                GL.PopMatrix();
                                GL.PushMatrix();
                                GL.Translate(ptList[i].easting, ptList[i].northing, 0);
                                DrawCircle(1);
                                GL.PopMatrix();

                        }


                        }

                    }
                   
                }


            }
           
        //Reset the Tree to zip
        public void ResetTree()
        {
            if (ptList != null) ptList.Clear();
        }
    }//class
}//namespace
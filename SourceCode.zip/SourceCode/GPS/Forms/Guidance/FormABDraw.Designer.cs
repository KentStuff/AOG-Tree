﻿namespace AgOpenGPS
{
    partial class FormABDraw
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.oglSelf = new OpenTK.GLControl();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.btnExit = new System.Windows.Forms.Button();
            this.btnMakeABLine = new System.Windows.Forms.Button();
            this.btnMakeCurve = new System.Windows.Forms.Button();
            this.btnSelectCurve = new System.Windows.Forms.Button();
            this.btnSelectABLine = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnDeleteCurve = new System.Windows.Forms.Button();
            this.btnDeleteABLine = new System.Windows.Forms.Button();
            this.lblNumCu = new System.Windows.Forms.Label();
            this.lblNumAB = new System.Windows.Forms.Label();
            this.lblABSelected = new System.Windows.Forms.Label();
            this.lblCurveSelected = new System.Windows.Forms.Label();
            this.btnCancelTouch = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblABLineName = new System.Windows.Forms.Label();
            this.lblCurveName = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.nudDistance = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.btnDrawSections = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.StartTreeBtn = new System.Windows.Forms.Button();
            this.TreePanel = new System.Windows.Forms.Panel();
            this.AutoPlantCheck = new System.Windows.Forms.CheckBox();
            this.Angle = new System.Windows.Forms.Label();
            this.TreeCount = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.CloseTreePanelBtn = new System.Windows.Forms.Button();
            this.NudRotate = new System.Windows.Forms.NumericUpDown();
            this.DrawTreesButton = new System.Windows.Forms.Button();
            this.NudRows = new System.Windows.Forms.NumericUpDown();
            this.NudCols = new System.Windows.Forms.NumericUpDown();
            this.NudYSpace = new System.Windows.Forms.NumericUpDown();
            this.NudXSpace = new System.Windows.Forms.NumericUpDown();
            this.AStartButton = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.nudDistance)).BeginInit();
            this.TreePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NudRotate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudRows)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudCols)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudYSpace)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudXSpace)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // oglSelf
            // 
            this.oglSelf.BackColor = System.Drawing.Color.Black;
            this.oglSelf.Cursor = System.Windows.Forms.Cursors.Cross;
            this.oglSelf.Location = new System.Drawing.Point(5, 7);
            this.oglSelf.Margin = new System.Windows.Forms.Padding(0);
            this.oglSelf.Name = "oglSelf";
            this.oglSelf.Size = new System.Drawing.Size(700, 700);
            this.oglSelf.TabIndex = 183;
            this.oglSelf.VSync = false;
            this.oglSelf.Load += new System.EventHandler(this.oglSelf_Load);
            this.oglSelf.Paint += new System.Windows.Forms.PaintEventHandler(this.oglSelf_Paint);
            this.oglSelf.MouseDown += new System.Windows.Forms.MouseEventHandler(this.oglSelf_MouseDown);
            this.oglSelf.Resize += new System.EventHandler(this.oglSelf_Resize);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 250;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // btnExit
            // 
            this.btnExit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnExit.Image = global::AgOpenGPS.Properties.Resources.OK64;
            this.btnExit.Location = new System.Drawing.Point(875, 637);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(123, 70);
            this.btnExit.TabIndex = 234;
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnMakeABLine
            // 
            this.btnMakeABLine.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMakeABLine.BackColor = System.Drawing.Color.Lavender;
            this.btnMakeABLine.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnMakeABLine.Enabled = false;
            this.btnMakeABLine.FlatAppearance.BorderColor = System.Drawing.SystemColors.HotTrack;
            this.btnMakeABLine.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMakeABLine.Font = new System.Drawing.Font("Tahoma", 14.25F);
            this.btnMakeABLine.Image = global::AgOpenGPS.Properties.Resources.ABLineOn;
            this.btnMakeABLine.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnMakeABLine.Location = new System.Drawing.Point(799, 106);
            this.btnMakeABLine.Name = "btnMakeABLine";
            this.btnMakeABLine.Size = new System.Drawing.Size(80, 69);
            this.btnMakeABLine.TabIndex = 311;
            this.btnMakeABLine.UseVisualStyleBackColor = false;
            this.btnMakeABLine.Click += new System.EventHandler(this.BtnMakeABLine_Click);
            // 
            // btnMakeCurve
            // 
            this.btnMakeCurve.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMakeCurve.BackColor = System.Drawing.Color.Lavender;
            this.btnMakeCurve.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnMakeCurve.Enabled = false;
            this.btnMakeCurve.FlatAppearance.BorderColor = System.Drawing.SystemColors.HotTrack;
            this.btnMakeCurve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMakeCurve.Font = new System.Drawing.Font("Tahoma", 14.25F);
            this.btnMakeCurve.Image = global::AgOpenGPS.Properties.Resources.CurveOn;
            this.btnMakeCurve.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnMakeCurve.Location = new System.Drawing.Point(713, 106);
            this.btnMakeCurve.Name = "btnMakeCurve";
            this.btnMakeCurve.Size = new System.Drawing.Size(80, 69);
            this.btnMakeCurve.TabIndex = 313;
            this.btnMakeCurve.UseVisualStyleBackColor = false;
            this.btnMakeCurve.Click += new System.EventHandler(this.BtnMakeCurve_Click);
            // 
            // btnSelectCurve
            // 
            this.btnSelectCurve.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSelectCurve.BackColor = System.Drawing.Color.Lavender;
            this.btnSelectCurve.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSelectCurve.FlatAppearance.BorderColor = System.Drawing.SystemColors.HotTrack;
            this.btnSelectCurve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSelectCurve.Font = new System.Drawing.Font("Tahoma", 14.25F);
            this.btnSelectCurve.Image = global::AgOpenGPS.Properties.Resources.CurveOn;
            this.btnSelectCurve.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnSelectCurve.Location = new System.Drawing.Point(731, 286);
            this.btnSelectCurve.Name = "btnSelectCurve";
            this.btnSelectCurve.Size = new System.Drawing.Size(82, 85);
            this.btnSelectCurve.TabIndex = 321;
            this.btnSelectCurve.UseVisualStyleBackColor = false;
            this.btnSelectCurve.Click += new System.EventHandler(this.btnSelectCurve_Click);
            // 
            // btnSelectABLine
            // 
            this.btnSelectABLine.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSelectABLine.BackColor = System.Drawing.Color.Lavender;
            this.btnSelectABLine.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSelectABLine.FlatAppearance.BorderColor = System.Drawing.SystemColors.HotTrack;
            this.btnSelectABLine.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSelectABLine.Font = new System.Drawing.Font("Tahoma", 14.25F);
            this.btnSelectABLine.Image = global::AgOpenGPS.Properties.Resources.ABLineOn;
            this.btnSelectABLine.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnSelectABLine.Location = new System.Drawing.Point(731, 418);
            this.btnSelectABLine.Name = "btnSelectABLine";
            this.btnSelectABLine.Size = new System.Drawing.Size(82, 85);
            this.btnSelectABLine.TabIndex = 322;
            this.btnSelectABLine.UseVisualStyleBackColor = false;
            this.btnSelectABLine.Click += new System.EventHandler(this.btnSelectABLine_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel1.Location = new System.Drawing.Point(706, 237);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(286, 5);
            this.panel1.TabIndex = 323;
            // 
            // btnDeleteCurve
            // 
            this.btnDeleteCurve.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDeleteCurve.BackColor = System.Drawing.Color.Lavender;
            this.btnDeleteCurve.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnDeleteCurve.FlatAppearance.BorderColor = System.Drawing.SystemColors.HotTrack;
            this.btnDeleteCurve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDeleteCurve.Font = new System.Drawing.Font("Tahoma", 14.25F);
            this.btnDeleteCurve.Image = global::AgOpenGPS.Properties.Resources.FileDelete;
            this.btnDeleteCurve.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnDeleteCurve.Location = new System.Drawing.Point(904, 286);
            this.btnDeleteCurve.Name = "btnDeleteCurve";
            this.btnDeleteCurve.Size = new System.Drawing.Size(88, 78);
            this.btnDeleteCurve.TabIndex = 325;
            this.btnDeleteCurve.UseVisualStyleBackColor = false;
            this.btnDeleteCurve.Click += new System.EventHandler(this.btnDeleteCurve_Click);
            // 
            // btnDeleteABLine
            // 
            this.btnDeleteABLine.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDeleteABLine.BackColor = System.Drawing.Color.Lavender;
            this.btnDeleteABLine.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnDeleteABLine.FlatAppearance.BorderColor = System.Drawing.SystemColors.HotTrack;
            this.btnDeleteABLine.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDeleteABLine.Font = new System.Drawing.Font("Tahoma", 14.25F);
            this.btnDeleteABLine.Image = global::AgOpenGPS.Properties.Resources.FileDelete;
            this.btnDeleteABLine.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnDeleteABLine.Location = new System.Drawing.Point(904, 418);
            this.btnDeleteABLine.Name = "btnDeleteABLine";
            this.btnDeleteABLine.Size = new System.Drawing.Size(88, 78);
            this.btnDeleteABLine.TabIndex = 326;
            this.btnDeleteABLine.UseVisualStyleBackColor = false;
            this.btnDeleteABLine.Click += new System.EventHandler(this.btnDeleteABLine_Click);
            // 
            // lblNumCu
            // 
            this.lblNumCu.Enabled = false;
            this.lblNumCu.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumCu.Location = new System.Drawing.Point(795, 255);
            this.lblNumCu.Margin = new System.Windows.Forms.Padding(0);
            this.lblNumCu.Name = "lblNumCu";
            this.lblNumCu.Size = new System.Drawing.Size(35, 26);
            this.lblNumCu.TabIndex = 327;
            this.lblNumCu.Text = "1";
            this.lblNumCu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblNumAB
            // 
            this.lblNumAB.Enabled = false;
            this.lblNumAB.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumAB.Location = new System.Drawing.Point(794, 388);
            this.lblNumAB.Margin = new System.Windows.Forms.Padding(0);
            this.lblNumAB.Name = "lblNumAB";
            this.lblNumAB.Size = new System.Drawing.Size(35, 26);
            this.lblNumAB.TabIndex = 328;
            this.lblNumAB.Text = "2";
            this.lblNumAB.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblABSelected
            // 
            this.lblABSelected.Enabled = false;
            this.lblABSelected.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblABSelected.Location = new System.Drawing.Point(715, 388);
            this.lblABSelected.Margin = new System.Windows.Forms.Padding(0);
            this.lblABSelected.Name = "lblABSelected";
            this.lblABSelected.Size = new System.Drawing.Size(35, 26);
            this.lblABSelected.TabIndex = 330;
            this.lblABSelected.Text = "1";
            this.lblABSelected.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblCurveSelected
            // 
            this.lblCurveSelected.Enabled = false;
            this.lblCurveSelected.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurveSelected.Location = new System.Drawing.Point(716, 256);
            this.lblCurveSelected.Margin = new System.Windows.Forms.Padding(0);
            this.lblCurveSelected.Name = "lblCurveSelected";
            this.lblCurveSelected.Size = new System.Drawing.Size(35, 26);
            this.lblCurveSelected.TabIndex = 329;
            this.lblCurveSelected.Text = "1";
            this.lblCurveSelected.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnCancelTouch
            // 
            this.btnCancelTouch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancelTouch.BackColor = System.Drawing.Color.Lavender;
            this.btnCancelTouch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnCancelTouch.Enabled = false;
            this.btnCancelTouch.FlatAppearance.BorderColor = System.Drawing.SystemColors.HotTrack;
            this.btnCancelTouch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancelTouch.Font = new System.Drawing.Font("Tahoma", 14.25F);
            this.btnCancelTouch.Image = global::AgOpenGPS.Properties.Resources.Cancel64;
            this.btnCancelTouch.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnCancelTouch.Location = new System.Drawing.Point(934, 95);
            this.btnCancelTouch.Name = "btnCancelTouch";
            this.btnCancelTouch.Size = new System.Drawing.Size(58, 56);
            this.btnCancelTouch.TabIndex = 331;
            this.btnCancelTouch.UseVisualStyleBackColor = false;
            this.btnCancelTouch.Click += new System.EventHandler(this.btnCancelTouch_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Enabled = false;
            this.label1.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(758, 257);
            this.label1.Margin = new System.Windows.Forms.Padding(0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 23);
            this.label1.TabIndex = 332;
            this.label1.Text = "of";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Enabled = false;
            this.label2.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(758, 391);
            this.label2.Margin = new System.Windows.Forms.Padding(0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 23);
            this.label2.TabIndex = 333;
            this.label2.Text = "of";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblABLineName
            // 
            this.lblABLineName.Enabled = false;
            this.lblABLineName.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblABLineName.Location = new System.Drawing.Point(716, 509);
            this.lblABLineName.Margin = new System.Windows.Forms.Padding(0);
            this.lblABLineName.Name = "lblABLineName";
            this.lblABLineName.Size = new System.Drawing.Size(284, 26);
            this.lblABLineName.TabIndex = 334;
            this.lblABLineName.Text = "Name";
            this.lblABLineName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCurveName
            // 
            this.lblCurveName.Enabled = false;
            this.lblCurveName.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurveName.Location = new System.Drawing.Point(728, 367);
            this.lblCurveName.Margin = new System.Windows.Forms.Padding(0);
            this.lblCurveName.Name = "lblCurveName";
            this.lblCurveName.Size = new System.Drawing.Size(266, 26);
            this.lblCurveName.TabIndex = 335;
            this.lblCurveName.Text = "Name";
            this.lblCurveName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Enabled = false;
            this.label3.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(714, 1);
            this.label3.Margin = new System.Windows.Forms.Padding(0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(284, 25);
            this.label3.TabIndex = 336;
            this.label3.Text = "gsCreate";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label4
            // 
            this.label4.Enabled = false;
            this.label4.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(716, 208);
            this.label4.Margin = new System.Windows.Forms.Padding(0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(266, 26);
            this.label4.TabIndex = 337;
            this.label4.Text = "gsSelect";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // nudDistance
            // 
            this.nudDistance.BackColor = System.Drawing.Color.AliceBlue;
            this.nudDistance.Font = new System.Drawing.Font("Tahoma", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudDistance.Location = new System.Drawing.Point(860, 35);
            this.nudDistance.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.nudDistance.Minimum = new decimal(new int[] {
            5000,
            0,
            0,
            -2147483648});
            this.nudDistance.Name = "nudDistance";
            this.nudDistance.Size = new System.Drawing.Size(132, 52);
            this.nudDistance.TabIndex = 338;
            this.nudDistance.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nudDistance.Enter += new System.EventHandler(this.nudDistance_Enter);
            // 
            // label5
            // 
            this.label5.Enabled = false;
            this.label5.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(705, 26);
            this.label5.Margin = new System.Windows.Forms.Padding(0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(146, 38);
            this.label5.TabIndex = 339;
            this.label5.Text = "Tool Width (cm)";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnDrawSections
            // 
            this.btnDrawSections.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDrawSections.BackColor = System.Drawing.Color.Lavender;
            this.btnDrawSections.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDrawSections.FlatAppearance.BorderColor = System.Drawing.SystemColors.HotTrack;
            this.btnDrawSections.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDrawSections.Font = new System.Drawing.Font("Tahoma", 14.25F);
            this.btnDrawSections.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnDrawSections.Location = new System.Drawing.Point(732, 642);
            this.btnDrawSections.Name = "btnDrawSections";
            this.btnDrawSections.Size = new System.Drawing.Size(89, 63);
            this.btnDrawSections.TabIndex = 340;
            this.btnDrawSections.Text = "Off";
            this.btnDrawSections.UseVisualStyleBackColor = false;
            this.btnDrawSections.Click += new System.EventHandler(this.btnDrawSections_Click);
            // 
            // label6
            // 
            this.label6.Enabled = false;
            this.label6.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(709, 67);
            this.label6.Margin = new System.Windows.Forms.Padding(0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 25);
            this.label6.TabIndex = 341;
            this.label6.Text = "2";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // StartTreeBtn
            // 
            this.StartTreeBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.StartTreeBtn.BackColor = System.Drawing.Color.Lavender;
            this.StartTreeBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.StartTreeBtn.FlatAppearance.BorderColor = System.Drawing.SystemColors.HotTrack;
            this.StartTreeBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.StartTreeBtn.Font = new System.Drawing.Font("Tahoma", 14.25F);
            this.StartTreeBtn.Image = global::AgOpenGPS.Properties.Resources.tree;
            this.StartTreeBtn.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.StartTreeBtn.Location = new System.Drawing.Point(731, 526);
            this.StartTreeBtn.Name = "StartTreeBtn";
            this.StartTreeBtn.Size = new System.Drawing.Size(82, 85);
            this.StartTreeBtn.TabIndex = 342;
            this.StartTreeBtn.UseVisualStyleBackColor = false;
            this.StartTreeBtn.Click += new System.EventHandler(this.StartTreeBtn_Click);
            // 
            // TreePanel
            // 
            this.TreePanel.Controls.Add(this.AutoPlantCheck);
            this.TreePanel.Controls.Add(this.Angle);
            this.TreePanel.Controls.Add(this.TreeCount);
            this.TreePanel.Controls.Add(this.button1);
            this.TreePanel.Controls.Add(this.label14);
            this.TreePanel.Controls.Add(this.label13);
            this.TreePanel.Controls.Add(this.label11);
            this.TreePanel.Controls.Add(this.label10);
            this.TreePanel.Controls.Add(this.label9);
            this.TreePanel.Controls.Add(this.label8);
            this.TreePanel.Controls.Add(this.CloseTreePanelBtn);
            this.TreePanel.Controls.Add(this.NudRotate);
            this.TreePanel.Controls.Add(this.DrawTreesButton);
            this.TreePanel.Controls.Add(this.NudRows);
            this.TreePanel.Controls.Add(this.NudCols);
            this.TreePanel.Controls.Add(this.NudYSpace);
            this.TreePanel.Controls.Add(this.NudXSpace);
            this.TreePanel.Controls.Add(this.AStartButton);
            this.TreePanel.Controls.Add(this.panel3);
            this.TreePanel.Location = new System.Drawing.Point(708, 260);
            this.TreePanel.Name = "TreePanel";
            this.TreePanel.Size = new System.Drawing.Size(300, 447);
            this.TreePanel.TabIndex = 343;
            this.TreePanel.Visible = false;
            // 
            // AutoPlantCheck
            // 
            this.AutoPlantCheck.Appearance = System.Windows.Forms.Appearance.Button;
            this.AutoPlantCheck.Checked = true;
            this.AutoPlantCheck.CheckState = System.Windows.Forms.CheckState.Checked;
            this.AutoPlantCheck.FlatAppearance.CheckedBackColor = System.Drawing.Color.Lime;
            this.AutoPlantCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AutoPlantCheck.Location = new System.Drawing.Point(10, 76);
            this.AutoPlantCheck.Name = "AutoPlantCheck";
            this.AutoPlantCheck.Size = new System.Drawing.Size(84, 78);
            this.AutoPlantCheck.TabIndex = 358;
            this.AutoPlantCheck.Text = "Auto Plant?";
            this.AutoPlantCheck.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.AutoPlantCheck.UseVisualStyleBackColor = true;
            this.AutoPlantCheck.CheckedChanged += new System.EventHandler(this.AutoPlantCheck_CheckedChanged);
            // 
            // Angle
            // 
            this.Angle.AutoSize = true;
            this.Angle.Enabled = false;
            this.Angle.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Angle.Location = new System.Drawing.Point(35, 199);
            this.Angle.Margin = new System.Windows.Forms.Padding(0);
            this.Angle.Name = "Angle";
            this.Angle.Size = new System.Drawing.Size(144, 23);
            this.Angle.TabIndex = 356;
            this.Angle.Text = "Angle (°CCW)";
            this.Angle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TreeCount
            // 
            this.TreeCount.AutoSize = true;
            this.TreeCount.Enabled = false;
            this.TreeCount.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TreeCount.Location = new System.Drawing.Point(192, 351);
            this.TreeCount.Margin = new System.Windows.Forms.Padding(0);
            this.TreeCount.Name = "TreeCount";
            this.TreeCount.Size = new System.Drawing.Size(22, 23);
            this.TreeCount.TabIndex = 355;
            this.TreeCount.Text = "0";
            this.TreeCount.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackColor = System.Drawing.Color.Lavender;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button1.FlatAppearance.BorderColor = System.Drawing.SystemColors.HotTrack;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Tahoma", 14.25F);
            this.button1.Image = global::AgOpenGPS.Properties.Resources.FlagDeleteAll;
            this.button1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button1.Location = new System.Drawing.Point(97, 351);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(82, 91);
            this.button1.TabIndex = 353;
            this.button1.Text = "Reset";
            this.button1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Enabled = false;
            this.label14.Font = new System.Drawing.Font("Tahoma", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(148, 248);
            this.label14.Margin = new System.Windows.Forms.Padding(0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(90, 23);
            this.label14.TabIndex = 352;
            this.label14.Text = "Grid (#)";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Enabled = false;
            this.label13.Font = new System.Drawing.Font("Tahoma", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(149, 63);
            this.label13.Margin = new System.Windows.Forms.Padding(0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(137, 23);
            this.label13.TabIndex = 351;
            this.label13.Text = "Spacing (cm)";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Enabled = false;
            this.label11.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(108, 318);
            this.label11.Margin = new System.Windows.Forms.Padding(0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(71, 23);
            this.label11.TabIndex = 349;
            this.label11.Text = "ROWS";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Enabled = false;
            this.label10.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(118, 280);
            this.label10.Margin = new System.Windows.Forms.Padding(0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(61, 23);
            this.label10.TabIndex = 348;
            this.label10.Text = "COLS";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Enabled = false;
            this.label9.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(127, 155);
            this.label9.Margin = new System.Windows.Forms.Padding(0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(23, 23);
            this.label9.TabIndex = 347;
            this.label9.Text = "Y";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Enabled = false;
            this.label8.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(127, 101);
            this.label8.Margin = new System.Windows.Forms.Padding(0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(23, 23);
            this.label8.TabIndex = 346;
            this.label8.Text = "X";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CloseTreePanelBtn
            // 
            this.CloseTreePanelBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.CloseTreePanelBtn.BackColor = System.Drawing.Color.Lavender;
            this.CloseTreePanelBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.CloseTreePanelBtn.FlatAppearance.BorderColor = System.Drawing.SystemColors.HotTrack;
            this.CloseTreePanelBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CloseTreePanelBtn.Font = new System.Drawing.Font("Tahoma", 14.25F);
            this.CloseTreePanelBtn.Image = global::AgOpenGPS.Properties.Resources.back_button;
            this.CloseTreePanelBtn.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.CloseTreePanelBtn.Location = new System.Drawing.Point(228, 377);
            this.CloseTreePanelBtn.Name = "CloseTreePanelBtn";
            this.CloseTreePanelBtn.Size = new System.Drawing.Size(58, 56);
            this.CloseTreePanelBtn.TabIndex = 345;
            this.CloseTreePanelBtn.UseVisualStyleBackColor = false;
            this.CloseTreePanelBtn.Click += new System.EventHandler(this.CloseTreePanelBtn_Click);
            // 
            // NudRotate
            // 
            this.NudRotate.DecimalPlaces = 1;
            this.NudRotate.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NudRotate.Location = new System.Drawing.Point(187, 197);
            this.NudRotate.Maximum = new decimal(new int[] {
            359,
            0,
            0,
            0});
            this.NudRotate.Minimum = new decimal(new int[] {
            359,
            0,
            0,
            -2147483648});
            this.NudRotate.Name = "NudRotate";
            this.NudRotate.Size = new System.Drawing.Size(100, 29);
            this.NudRotate.TabIndex = 344;
            // 
            // DrawTreesButton
            // 
            this.DrawTreesButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.DrawTreesButton.BackColor = System.Drawing.Color.Lavender;
            this.DrawTreesButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.DrawTreesButton.FlatAppearance.BorderColor = System.Drawing.SystemColors.HotTrack;
            this.DrawTreesButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DrawTreesButton.Font = new System.Drawing.Font("Tahoma", 14.25F);
            this.DrawTreesButton.Image = global::AgOpenGPS.Properties.Resources.AddNew;
            this.DrawTreesButton.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.DrawTreesButton.Location = new System.Drawing.Point(9, 351);
            this.DrawTreesButton.Name = "DrawTreesButton";
            this.DrawTreesButton.Size = new System.Drawing.Size(82, 91);
            this.DrawTreesButton.TabIndex = 343;
            this.DrawTreesButton.Text = "Apply";
            this.DrawTreesButton.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.DrawTreesButton.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.DrawTreesButton.UseVisualStyleBackColor = false;
            this.DrawTreesButton.Click += new System.EventHandler(this.DrawTreesButton_Click);
            // 
            // NudRows
            // 
            this.NudRows.Enabled = false;
            this.NudRows.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NudRows.Location = new System.Drawing.Point(196, 318);
            this.NudRows.Maximum = new decimal(new int[] {
            50000,
            0,
            0,
            0});
            this.NudRows.Minimum = new decimal(new int[] {
            50000,
            0,
            0,
            -2147483648});
            this.NudRows.Name = "NudRows";
            this.NudRows.Size = new System.Drawing.Size(90, 29);
            this.NudRows.TabIndex = 342;
            // 
            // NudCols
            // 
            this.NudCols.Enabled = false;
            this.NudCols.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NudCols.Location = new System.Drawing.Point(196, 278);
            this.NudCols.Maximum = new decimal(new int[] {
            50000,
            0,
            0,
            0});
            this.NudCols.Minimum = new decimal(new int[] {
            50000,
            0,
            0,
            -2147483648});
            this.NudCols.Name = "NudCols";
            this.NudCols.Size = new System.Drawing.Size(90, 29);
            this.NudCols.TabIndex = 341;
            // 
            // NudYSpace
            // 
            this.NudYSpace.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NudYSpace.Location = new System.Drawing.Point(153, 149);
            this.NudYSpace.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.NudYSpace.Minimum = new decimal(new int[] {
            5000,
            0,
            0,
            -2147483648});
            this.NudYSpace.Name = "NudYSpace";
            this.NudYSpace.Size = new System.Drawing.Size(134, 29);
            this.NudYSpace.TabIndex = 340;
            this.NudYSpace.Value = new decimal(new int[] {
            500,
            0,
            0,
            0});
            // 
            // NudXSpace
            // 
            this.NudXSpace.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NudXSpace.Location = new System.Drawing.Point(153, 95);
            this.NudXSpace.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.NudXSpace.Minimum = new decimal(new int[] {
            5000,
            0,
            0,
            -2147483648});
            this.NudXSpace.Name = "NudXSpace";
            this.NudXSpace.Size = new System.Drawing.Size(134, 29);
            this.NudXSpace.TabIndex = 339;
            this.NudXSpace.Value = new decimal(new int[] {
            500,
            0,
            0,
            0});
            // 
            // AStartButton
            // 
            this.AStartButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.AStartButton.BackColor = System.Drawing.Color.Lavender;
            this.AStartButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.AStartButton.FlatAppearance.BorderColor = System.Drawing.SystemColors.HotTrack;
            this.AStartButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AStartButton.Font = new System.Drawing.Font("Tahoma", 14.25F);
            this.AStartButton.Image = global::AgOpenGPS.Properties.Resources.LetterABlue;
            this.AStartButton.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.AStartButton.Location = new System.Drawing.Point(12, 235);
            this.AStartButton.Name = "AStartButton";
            this.AStartButton.Size = new System.Drawing.Size(82, 85);
            this.AStartButton.TabIndex = 337;
            this.AStartButton.UseVisualStyleBackColor = false;
            this.AStartButton.Click += new System.EventHandler(this.AStartButton_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.Highlight;
            this.panel3.Controls.Add(this.label7);
            this.panel3.Location = new System.Drawing.Point(3, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(290, 50);
            this.panel3.TabIndex = 336;
            // 
            // label7
            // 
            this.label7.Enabled = false;
            this.label7.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Lime;
            this.label7.Location = new System.Drawing.Point(44, 11);
            this.label7.Margin = new System.Windows.Forms.Padding(0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(200, 26);
            this.label7.TabIndex = 336;
            this.label7.Text = "Tree Planter Panel";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FormABDraw
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(1004, 709);
            this.ControlBox = false;
            this.Controls.Add(this.TreePanel);
            this.Controls.Add(this.StartTreeBtn);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btnDrawSections);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.nudDistance);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblABLineName);
            this.Controls.Add(this.btnCancelTouch);
            this.Controls.Add(this.lblABSelected);
            this.Controls.Add(this.lblCurveSelected);
            this.Controls.Add(this.lblNumAB);
            this.Controls.Add(this.lblNumCu);
            this.Controls.Add(this.btnDeleteABLine);
            this.Controls.Add(this.btnDeleteCurve);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnSelectABLine);
            this.Controls.Add(this.btnSelectCurve);
            this.Controls.Add(this.btnMakeCurve);
            this.Controls.Add(this.btnMakeABLine);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.oglSelf);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblCurveName);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormABDraw";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Click 2 points on the Boundary to Begin";
            this.Load += new System.EventHandler(this.FormABDraw_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nudDistance)).EndInit();
            this.TreePanel.ResumeLayout(false);
            this.TreePanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NudRotate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudRows)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudCols)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudYSpace)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudXSpace)).EndInit();
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private OpenTK.GLControl oglSelf;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnMakeABLine;
        private System.Windows.Forms.Button btnMakeCurve;
        private System.Windows.Forms.Button btnSelectCurve;
        private System.Windows.Forms.Button btnSelectABLine;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnDeleteCurve;
        private System.Windows.Forms.Button btnDeleteABLine;
        private System.Windows.Forms.Label lblNumCu;
        private System.Windows.Forms.Label lblNumAB;
        private System.Windows.Forms.Label lblABSelected;
        private System.Windows.Forms.Label lblCurveSelected;
        private System.Windows.Forms.Button btnCancelTouch;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblABLineName;
        private System.Windows.Forms.Label lblCurveName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown nudDistance;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnDrawSections;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button StartTreeBtn;
        private System.Windows.Forms.Panel TreePanel;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button CloseTreePanelBtn;
        private System.Windows.Forms.NumericUpDown NudRotate;
        private System.Windows.Forms.Button DrawTreesButton;
        private System.Windows.Forms.NumericUpDown NudRows;
        private System.Windows.Forms.NumericUpDown NudCols;
        private System.Windows.Forms.NumericUpDown NudYSpace;
        private System.Windows.Forms.NumericUpDown NudXSpace;
        private System.Windows.Forms.Button AStartButton;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label TreeCount;
        private System.Windows.Forms.Label Angle;
        private System.Windows.Forms.CheckBox AutoPlantCheck;
    }
}
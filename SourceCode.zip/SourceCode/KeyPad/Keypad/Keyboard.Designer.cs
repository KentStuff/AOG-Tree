﻿namespace Keypad
{
    partial class Keyboard
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.a3 = new System.Windows.Forms.Button();
            this.c7 = new System.Windows.Forms.Button();
            this.c8 = new System.Windows.Forms.Button();
            this.c9 = new System.Windows.Forms.Button();
            this.c10 = new System.Windows.Forms.Button();
            this.d1 = new System.Windows.Forms.Button();
            this.d2 = new System.Windows.Forms.Button();
            this.d3 = new System.Windows.Forms.Button();
            this.d4 = new System.Windows.Forms.Button();
            this.d5 = new System.Windows.Forms.Button();
            this.d6 = new System.Windows.Forms.Button();
            this.d7 = new System.Windows.Forms.Button();
            this.d8 = new System.Windows.Forms.Button();
            this.d9 = new System.Windows.Forms.Button();
            this.e3 = new System.Windows.Forms.Button();
            this.e4 = new System.Windows.Forms.Button();
            this.e5 = new System.Windows.Forms.Button();
            this.e6 = new System.Windows.Forms.Button();
            this.e7 = new System.Windows.Forms.Button();
            this.e8 = new System.Windows.Forms.Button();
            this.e9 = new System.Windows.Forms.Button();
            this.btn_space = new System.Windows.Forms.Button();
            this.btn_clear = new System.Windows.Forms.Button();
            this.a1 = new System.Windows.Forms.Button();
            this.a2 = new System.Windows.Forms.Button();
            this.a4 = new System.Windows.Forms.Button();
            this.a8 = new System.Windows.Forms.Button();
            this.a9 = new System.Windows.Forms.Button();
            this.a7 = new System.Windows.Forms.Button();
            this.c1 = new System.Windows.Forms.Button();
            this.a10 = new System.Windows.Forms.Button();
            this.a5 = new System.Windows.Forms.Button();
            this.a6 = new System.Windows.Forms.Button();
            this.c2 = new System.Windows.Forms.Button();
            this.c3 = new System.Windows.Forms.Button();
            this.c4 = new System.Windows.Forms.Button();
            this.c5 = new System.Windows.Forms.Button();
            this.c6 = new System.Windows.Forms.Button();
            this.chk_shift = new System.Windows.Forms.CheckBox();
            this.btn_backspace = new System.Windows.Forms.Button();
            this.btn_OK = new System.Windows.Forms.Button();
            this.btn_cancel = new System.Windows.Forms.Button();
            this.e11 = new System.Windows.Forms.Button();
            this.e1 = new System.Windows.Forms.Button();
            this.d10 = new System.Windows.Forms.Button();
            this.e10 = new System.Windows.Forms.Button();
            this.b6 = new System.Windows.Forms.Button();
            this.b5 = new System.Windows.Forms.Button();
            this.b4 = new System.Windows.Forms.Button();
            this.b3 = new System.Windows.Forms.Button();
            this.b2 = new System.Windows.Forms.Button();
            this.b1 = new System.Windows.Forms.Button();
            this.b10 = new System.Windows.Forms.Button();
            this.b9 = new System.Windows.Forms.Button();
            this.b8 = new System.Windows.Forms.Button();
            this.b7 = new System.Windows.Forms.Button();
            this.b11 = new System.Windows.Forms.Button();
            this.e12 = new System.Windows.Forms.Button();
            this.a11 = new System.Windows.Forms.Button();
            this.e2 = new System.Windows.Forms.Button();
            this.btnApos = new System.Windows.Forms.Button();
            this.c11 = new System.Windows.Forms.Button();
            this.c12 = new System.Windows.Forms.Button();
            this.b12 = new System.Windows.Forms.Button();
            this.d11 = new System.Windows.Forms.Button();
            this.d12 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // a3
            // 
            this.a3.BackColor = System.Drawing.SystemColors.Control;
            this.a3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.a3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a3.Location = new System.Drawing.Point(150, 1);
            this.a3.Name = "a3";
            this.a3.Size = new System.Drawing.Size(64, 64);
            this.a3.TabIndex = 0;
            this.a3.TabStop = false;
            this.a3.Text = "3";
            this.a3.UseVisualStyleBackColor = false;
            this.a3.Click += new System.EventHandler(this.BtnClick);
            // 
            // c7
            // 
            this.c7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.c7.BackColor = System.Drawing.SystemColors.Control;
            this.c7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c7.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c7.Location = new System.Drawing.Point(472, 212);
            this.c7.Name = "c7";
            this.c7.Size = new System.Drawing.Size(64, 64);
            this.c7.TabIndex = 1;
            this.c7.TabStop = false;
            this.c7.Text = "u";
            this.c7.UseVisualStyleBackColor = false;
            this.c7.Click += new System.EventHandler(this.BtnClick);
            // 
            // c8
            // 
            this.c8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.c8.BackColor = System.Drawing.SystemColors.Control;
            this.c8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c8.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c8.Location = new System.Drawing.Point(546, 212);
            this.c8.Name = "c8";
            this.c8.Size = new System.Drawing.Size(64, 64);
            this.c8.TabIndex = 2;
            this.c8.TabStop = false;
            this.c8.Text = "i";
            this.c8.UseVisualStyleBackColor = false;
            this.c8.Click += new System.EventHandler(this.BtnClick);
            // 
            // c9
            // 
            this.c9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.c9.BackColor = System.Drawing.SystemColors.Control;
            this.c9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c9.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c9.Location = new System.Drawing.Point(620, 212);
            this.c9.Name = "c9";
            this.c9.Size = new System.Drawing.Size(64, 64);
            this.c9.TabIndex = 3;
            this.c9.TabStop = false;
            this.c9.Text = "o";
            this.c9.UseVisualStyleBackColor = false;
            this.c9.Click += new System.EventHandler(this.BtnClick);
            // 
            // c10
            // 
            this.c10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.c10.BackColor = System.Drawing.SystemColors.Control;
            this.c10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c10.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c10.Location = new System.Drawing.Point(694, 212);
            this.c10.Name = "c10";
            this.c10.Size = new System.Drawing.Size(64, 64);
            this.c10.TabIndex = 4;
            this.c10.TabStop = false;
            this.c10.Text = "p";
            this.c10.UseVisualStyleBackColor = false;
            this.c10.Click += new System.EventHandler(this.BtnClick);
            // 
            // d1
            // 
            this.d1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.d1.BackColor = System.Drawing.SystemColors.Control;
            this.d1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.d1.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.d1.Location = new System.Drawing.Point(45, 293);
            this.d1.Name = "d1";
            this.d1.Size = new System.Drawing.Size(64, 64);
            this.d1.TabIndex = 5;
            this.d1.TabStop = false;
            this.d1.Text = "a";
            this.d1.UseVisualStyleBackColor = false;
            this.d1.Click += new System.EventHandler(this.BtnClick);
            // 
            // d2
            // 
            this.d2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.d2.BackColor = System.Drawing.SystemColors.Control;
            this.d2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.d2.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.d2.Location = new System.Drawing.Point(119, 293);
            this.d2.Name = "d2";
            this.d2.Size = new System.Drawing.Size(64, 64);
            this.d2.TabIndex = 6;
            this.d2.TabStop = false;
            this.d2.Text = "s";
            this.d2.UseVisualStyleBackColor = false;
            this.d2.Click += new System.EventHandler(this.BtnClick);
            // 
            // d3
            // 
            this.d3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.d3.BackColor = System.Drawing.SystemColors.Control;
            this.d3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.d3.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.d3.Location = new System.Drawing.Point(193, 293);
            this.d3.Name = "d3";
            this.d3.Size = new System.Drawing.Size(64, 64);
            this.d3.TabIndex = 7;
            this.d3.TabStop = false;
            this.d3.Text = "d";
            this.d3.UseVisualStyleBackColor = false;
            this.d3.Click += new System.EventHandler(this.BtnClick);
            // 
            // d4
            // 
            this.d4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.d4.BackColor = System.Drawing.SystemColors.Control;
            this.d4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.d4.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.d4.Location = new System.Drawing.Point(267, 293);
            this.d4.Name = "d4";
            this.d4.Size = new System.Drawing.Size(64, 64);
            this.d4.TabIndex = 8;
            this.d4.TabStop = false;
            this.d4.Text = "f";
            this.d4.UseVisualStyleBackColor = false;
            this.d4.Click += new System.EventHandler(this.BtnClick);
            // 
            // d5
            // 
            this.d5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.d5.BackColor = System.Drawing.SystemColors.Control;
            this.d5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.d5.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.d5.Location = new System.Drawing.Point(341, 293);
            this.d5.Name = "d5";
            this.d5.Size = new System.Drawing.Size(64, 64);
            this.d5.TabIndex = 9;
            this.d5.TabStop = false;
            this.d5.Text = "g";
            this.d5.UseVisualStyleBackColor = false;
            this.d5.Click += new System.EventHandler(this.BtnClick);
            // 
            // d6
            // 
            this.d6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.d6.BackColor = System.Drawing.SystemColors.Control;
            this.d6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.d6.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.d6.Location = new System.Drawing.Point(415, 293);
            this.d6.Name = "d6";
            this.d6.Size = new System.Drawing.Size(64, 64);
            this.d6.TabIndex = 10;
            this.d6.TabStop = false;
            this.d6.Text = "h";
            this.d6.UseVisualStyleBackColor = false;
            this.d6.Click += new System.EventHandler(this.BtnClick);
            // 
            // d7
            // 
            this.d7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.d7.BackColor = System.Drawing.SystemColors.Control;
            this.d7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.d7.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.d7.Location = new System.Drawing.Point(489, 293);
            this.d7.Name = "d7";
            this.d7.Size = new System.Drawing.Size(64, 64);
            this.d7.TabIndex = 11;
            this.d7.TabStop = false;
            this.d7.Text = "j";
            this.d7.UseVisualStyleBackColor = false;
            this.d7.Click += new System.EventHandler(this.BtnClick);
            // 
            // d8
            // 
            this.d8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.d8.BackColor = System.Drawing.SystemColors.Control;
            this.d8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.d8.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.d8.Location = new System.Drawing.Point(563, 293);
            this.d8.Name = "d8";
            this.d8.Size = new System.Drawing.Size(64, 64);
            this.d8.TabIndex = 12;
            this.d8.TabStop = false;
            this.d8.Text = "k";
            this.d8.UseVisualStyleBackColor = false;
            this.d8.Click += new System.EventHandler(this.BtnClick);
            // 
            // d9
            // 
            this.d9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.d9.BackColor = System.Drawing.SystemColors.Control;
            this.d9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.d9.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.d9.Location = new System.Drawing.Point(637, 293);
            this.d9.Name = "d9";
            this.d9.Size = new System.Drawing.Size(64, 64);
            this.d9.TabIndex = 13;
            this.d9.TabStop = false;
            this.d9.Text = "l";
            this.d9.UseVisualStyleBackColor = false;
            this.d9.Click += new System.EventHandler(this.BtnClick);
            // 
            // e3
            // 
            this.e3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.e3.BackColor = System.Drawing.SystemColors.Control;
            this.e3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.e3.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.e3.Location = new System.Drawing.Point(150, 375);
            this.e3.Name = "e3";
            this.e3.Size = new System.Drawing.Size(64, 64);
            this.e3.TabIndex = 14;
            this.e3.TabStop = false;
            this.e3.Text = "z";
            this.e3.UseVisualStyleBackColor = false;
            this.e3.Click += new System.EventHandler(this.BtnClick);
            // 
            // e4
            // 
            this.e4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.e4.BackColor = System.Drawing.SystemColors.Control;
            this.e4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.e4.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.e4.Location = new System.Drawing.Point(223, 375);
            this.e4.Name = "e4";
            this.e4.Size = new System.Drawing.Size(64, 64);
            this.e4.TabIndex = 15;
            this.e4.TabStop = false;
            this.e4.Text = "x";
            this.e4.UseVisualStyleBackColor = false;
            this.e4.Click += new System.EventHandler(this.BtnClick);
            // 
            // e5
            // 
            this.e5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.e5.BackColor = System.Drawing.SystemColors.Control;
            this.e5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.e5.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.e5.Location = new System.Drawing.Point(296, 375);
            this.e5.Name = "e5";
            this.e5.Size = new System.Drawing.Size(64, 64);
            this.e5.TabIndex = 16;
            this.e5.TabStop = false;
            this.e5.Text = "c";
            this.e5.UseVisualStyleBackColor = false;
            this.e5.Click += new System.EventHandler(this.BtnClick);
            // 
            // e6
            // 
            this.e6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.e6.BackColor = System.Drawing.SystemColors.Control;
            this.e6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.e6.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.e6.Location = new System.Drawing.Point(369, 375);
            this.e6.Name = "e6";
            this.e6.Size = new System.Drawing.Size(64, 64);
            this.e6.TabIndex = 17;
            this.e6.TabStop = false;
            this.e6.Text = "v";
            this.e6.UseVisualStyleBackColor = false;
            this.e6.Click += new System.EventHandler(this.BtnClick);
            // 
            // e7
            // 
            this.e7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.e7.BackColor = System.Drawing.SystemColors.Control;
            this.e7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.e7.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.e7.Location = new System.Drawing.Point(442, 375);
            this.e7.Name = "e7";
            this.e7.Size = new System.Drawing.Size(64, 64);
            this.e7.TabIndex = 18;
            this.e7.TabStop = false;
            this.e7.Text = "b";
            this.e7.UseVisualStyleBackColor = false;
            this.e7.Click += new System.EventHandler(this.BtnClick);
            // 
            // e8
            // 
            this.e8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.e8.BackColor = System.Drawing.SystemColors.Control;
            this.e8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.e8.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.e8.Location = new System.Drawing.Point(515, 375);
            this.e8.Name = "e8";
            this.e8.Size = new System.Drawing.Size(64, 64);
            this.e8.TabIndex = 19;
            this.e8.TabStop = false;
            this.e8.Text = "n";
            this.e8.UseVisualStyleBackColor = false;
            this.e8.Click += new System.EventHandler(this.BtnClick);
            // 
            // e9
            // 
            this.e9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.e9.BackColor = System.Drawing.SystemColors.Control;
            this.e9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.e9.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.e9.Location = new System.Drawing.Point(588, 375);
            this.e9.Name = "e9";
            this.e9.Size = new System.Drawing.Size(64, 64);
            this.e9.TabIndex = 20;
            this.e9.TabStop = false;
            this.e9.Text = "m";
            this.e9.UseVisualStyleBackColor = false;
            this.e9.Click += new System.EventHandler(this.BtnClick);
            // 
            // btn_space
            // 
            this.btn_space.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_space.BackColor = System.Drawing.SystemColors.Control;
            this.btn_space.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_space.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_space.Location = new System.Drawing.Point(575, 456);
            this.btn_space.Name = "btn_space";
            this.btn_space.Size = new System.Drawing.Size(144, 63);
            this.btn_space.TabIndex = 23;
            this.btn_space.TabStop = false;
            this.btn_space.Text = "__";
            this.btn_space.UseVisualStyleBackColor = false;
            this.btn_space.Click += new System.EventHandler(this.Btn_space_Click);
            // 
            // btn_clear
            // 
            this.btn_clear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_clear.BackColor = System.Drawing.Color.LightSalmon;
            this.btn_clear.FlatAppearance.BorderSize = 0;
            this.btn_clear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_clear.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_clear.Location = new System.Drawing.Point(109, 457);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(85, 63);
            this.btn_clear.TabIndex = 24;
            this.btn_clear.TabStop = false;
            this.btn_clear.Text = "Clr";
            this.btn_clear.UseVisualStyleBackColor = false;
            this.btn_clear.Click += new System.EventHandler(this.Btn_clear_Click);
            // 
            // a1
            // 
            this.a1.BackColor = System.Drawing.SystemColors.Control;
            this.a1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.a1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a1.Location = new System.Drawing.Point(4, 1);
            this.a1.Name = "a1";
            this.a1.Size = new System.Drawing.Size(64, 64);
            this.a1.TabIndex = 25;
            this.a1.TabStop = false;
            this.a1.Text = "1";
            this.a1.UseVisualStyleBackColor = false;
            this.a1.Click += new System.EventHandler(this.BtnClick);
            // 
            // a2
            // 
            this.a2.BackColor = System.Drawing.SystemColors.Control;
            this.a2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.a2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a2.Location = new System.Drawing.Point(77, 1);
            this.a2.Name = "a2";
            this.a2.Size = new System.Drawing.Size(64, 64);
            this.a2.TabIndex = 26;
            this.a2.TabStop = false;
            this.a2.Text = "2";
            this.a2.UseVisualStyleBackColor = false;
            this.a2.Click += new System.EventHandler(this.BtnClick);
            // 
            // a4
            // 
            this.a4.BackColor = System.Drawing.SystemColors.Control;
            this.a4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.a4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a4.Location = new System.Drawing.Point(223, 1);
            this.a4.Name = "a4";
            this.a4.Size = new System.Drawing.Size(64, 64);
            this.a4.TabIndex = 27;
            this.a4.TabStop = false;
            this.a4.Text = "4";
            this.a4.UseVisualStyleBackColor = false;
            this.a4.Click += new System.EventHandler(this.BtnClick);
            // 
            // a8
            // 
            this.a8.BackColor = System.Drawing.SystemColors.Control;
            this.a8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.a8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a8.Location = new System.Drawing.Point(515, 1);
            this.a8.Name = "a8";
            this.a8.Size = new System.Drawing.Size(64, 64);
            this.a8.TabIndex = 28;
            this.a8.TabStop = false;
            this.a8.Text = "8";
            this.a8.UseVisualStyleBackColor = false;
            this.a8.Click += new System.EventHandler(this.BtnClick);
            // 
            // a9
            // 
            this.a9.BackColor = System.Drawing.SystemColors.Control;
            this.a9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.a9.Font = new System.Drawing.Font("Arial Rounded MT Bold", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a9.Location = new System.Drawing.Point(588, 1);
            this.a9.Name = "a9";
            this.a9.Size = new System.Drawing.Size(64, 64);
            this.a9.TabIndex = 29;
            this.a9.TabStop = false;
            this.a9.Text = "9";
            this.a9.UseVisualStyleBackColor = false;
            this.a9.Click += new System.EventHandler(this.BtnClick);
            // 
            // a7
            // 
            this.a7.BackColor = System.Drawing.SystemColors.Control;
            this.a7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.a7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a7.Location = new System.Drawing.Point(442, 1);
            this.a7.Name = "a7";
            this.a7.Size = new System.Drawing.Size(64, 64);
            this.a7.TabIndex = 30;
            this.a7.TabStop = false;
            this.a7.Text = "7";
            this.a7.UseVisualStyleBackColor = false;
            this.a7.Click += new System.EventHandler(this.BtnClick);
            // 
            // c1
            // 
            this.c1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.c1.BackColor = System.Drawing.SystemColors.Control;
            this.c1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c1.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c1.Location = new System.Drawing.Point(28, 212);
            this.c1.Name = "c1";
            this.c1.Size = new System.Drawing.Size(64, 64);
            this.c1.TabIndex = 31;
            this.c1.TabStop = false;
            this.c1.Text = "q";
            this.c1.UseVisualStyleBackColor = false;
            this.c1.Click += new System.EventHandler(this.BtnClick);
            // 
            // a10
            // 
            this.a10.BackColor = System.Drawing.SystemColors.Control;
            this.a10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.a10.Font = new System.Drawing.Font("Arial Rounded MT Bold", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a10.Location = new System.Drawing.Point(661, 1);
            this.a10.Name = "a10";
            this.a10.Size = new System.Drawing.Size(64, 64);
            this.a10.TabIndex = 32;
            this.a10.TabStop = false;
            this.a10.Text = "0";
            this.a10.UseVisualStyleBackColor = false;
            this.a10.Click += new System.EventHandler(this.BtnClick);
            // 
            // a5
            // 
            this.a5.BackColor = System.Drawing.SystemColors.Control;
            this.a5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.a5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a5.Location = new System.Drawing.Point(296, 1);
            this.a5.Name = "a5";
            this.a5.Size = new System.Drawing.Size(64, 64);
            this.a5.TabIndex = 33;
            this.a5.TabStop = false;
            this.a5.Text = "5";
            this.a5.UseVisualStyleBackColor = false;
            this.a5.Click += new System.EventHandler(this.BtnClick);
            // 
            // a6
            // 
            this.a6.BackColor = System.Drawing.SystemColors.Control;
            this.a6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.a6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a6.Location = new System.Drawing.Point(369, 1);
            this.a6.Name = "a6";
            this.a6.Size = new System.Drawing.Size(64, 64);
            this.a6.TabIndex = 34;
            this.a6.TabStop = false;
            this.a6.Text = "6";
            this.a6.UseVisualStyleBackColor = false;
            this.a6.Click += new System.EventHandler(this.BtnClick);
            // 
            // c2
            // 
            this.c2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.c2.BackColor = System.Drawing.SystemColors.Control;
            this.c2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c2.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c2.Location = new System.Drawing.Point(102, 212);
            this.c2.Name = "c2";
            this.c2.Size = new System.Drawing.Size(64, 64);
            this.c2.TabIndex = 35;
            this.c2.TabStop = false;
            this.c2.Text = "w";
            this.c2.UseVisualStyleBackColor = false;
            this.c2.Click += new System.EventHandler(this.BtnClick);
            // 
            // c3
            // 
            this.c3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.c3.BackColor = System.Drawing.SystemColors.Control;
            this.c3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c3.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c3.Location = new System.Drawing.Point(176, 212);
            this.c3.Name = "c3";
            this.c3.Size = new System.Drawing.Size(64, 64);
            this.c3.TabIndex = 36;
            this.c3.TabStop = false;
            this.c3.Text = "e";
            this.c3.UseVisualStyleBackColor = false;
            this.c3.Click += new System.EventHandler(this.BtnClick);
            // 
            // c4
            // 
            this.c4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.c4.BackColor = System.Drawing.SystemColors.Control;
            this.c4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c4.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c4.Location = new System.Drawing.Point(250, 212);
            this.c4.Name = "c4";
            this.c4.Size = new System.Drawing.Size(64, 64);
            this.c4.TabIndex = 37;
            this.c4.TabStop = false;
            this.c4.Text = "r";
            this.c4.UseVisualStyleBackColor = false;
            this.c4.Click += new System.EventHandler(this.BtnClick);
            // 
            // c5
            // 
            this.c5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.c5.BackColor = System.Drawing.SystemColors.Control;
            this.c5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c5.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c5.Location = new System.Drawing.Point(324, 212);
            this.c5.Name = "c5";
            this.c5.Size = new System.Drawing.Size(64, 64);
            this.c5.TabIndex = 38;
            this.c5.TabStop = false;
            this.c5.Text = "t";
            this.c5.UseVisualStyleBackColor = false;
            this.c5.Click += new System.EventHandler(this.BtnClick);
            // 
            // c6
            // 
            this.c6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.c6.BackColor = System.Drawing.SystemColors.Control;
            this.c6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c6.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c6.Location = new System.Drawing.Point(398, 212);
            this.c6.Name = "c6";
            this.c6.Size = new System.Drawing.Size(64, 64);
            this.c6.TabIndex = 39;
            this.c6.TabStop = false;
            this.c6.Text = "y";
            this.c6.UseVisualStyleBackColor = false;
            this.c6.Click += new System.EventHandler(this.BtnClick);
            // 
            // chk_shift
            // 
            this.chk_shift.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.chk_shift.Appearance = System.Windows.Forms.Appearance.Button;
            this.chk_shift.BackColor = System.Drawing.SystemColors.Control;
            this.chk_shift.BackgroundImage = global::Keypad.Properties.Resources.Shift;
            this.chk_shift.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.chk_shift.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.chk_shift.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.chk_shift.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_shift.Location = new System.Drawing.Point(310, 456);
            this.chk_shift.Name = "chk_shift";
            this.chk_shift.Size = new System.Drawing.Size(237, 63);
            this.chk_shift.TabIndex = 43;
            this.chk_shift.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chk_shift.UseVisualStyleBackColor = false;
            this.chk_shift.CheckedChanged += new System.EventHandler(this.Chk_shift_CheckedChanged);
            // 
            // btn_backspace
            // 
            this.btn_backspace.BackColor = System.Drawing.SystemColors.Control;
            this.btn_backspace.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_backspace.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_backspace.Image = global::Keypad.Properties.Resources.backspace;
            this.btn_backspace.Location = new System.Drawing.Point(811, 1);
            this.btn_backspace.Name = "btn_backspace";
            this.btn_backspace.Size = new System.Drawing.Size(111, 64);
            this.btn_backspace.TabIndex = 42;
            this.btn_backspace.TabStop = false;
            this.btn_backspace.UseVisualStyleBackColor = false;
            this.btn_backspace.Click += new System.EventHandler(this.Btn_backspace_Click);
            // 
            // btn_OK
            // 
            this.btn_OK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_OK.BackColor = System.Drawing.SystemColors.Control;
            this.btn_OK.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_OK.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_OK.Image = global::Keypad.Properties.Resources.OK64;
            this.btn_OK.Location = new System.Drawing.Point(747, 456);
            this.btn_OK.Name = "btn_OK";
            this.btn_OK.Size = new System.Drawing.Size(176, 63);
            this.btn_OK.TabIndex = 41;
            this.btn_OK.TabStop = false;
            this.btn_OK.UseVisualStyleBackColor = false;
            this.btn_OK.Click += new System.EventHandler(this.Btn_OK_Click);
            // 
            // btn_cancel
            // 
            this.btn_cancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_cancel.BackColor = System.Drawing.SystemColors.Control;
            this.btn_cancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_cancel.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cancel.Image = global::Keypad.Properties.Resources.Cancel64;
            this.btn_cancel.Location = new System.Drawing.Point(9, 457);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(87, 63);
            this.btn_cancel.TabIndex = 40;
            this.btn_cancel.TabStop = false;
            this.btn_cancel.UseVisualStyleBackColor = false;
            this.btn_cancel.Click += new System.EventHandler(this.Btn_cancel_Click);
            // 
            // e11
            // 
            this.e11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.e11.BackColor = System.Drawing.SystemColors.Control;
            this.e11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.e11.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.e11.Location = new System.Drawing.Point(736, 374);
            this.e11.Name = "e11";
            this.e11.Size = new System.Drawing.Size(64, 64);
            this.e11.TabIndex = 46;
            this.e11.TabStop = false;
            this.e11.Text = ".";
            this.e11.UseVisualStyleBackColor = false;
            this.e11.Click += new System.EventHandler(this.BtnClick);
            // 
            // e1
            // 
            this.e1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.e1.BackColor = System.Drawing.SystemColors.Control;
            this.e1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.e1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.e1.Location = new System.Drawing.Point(4, 375);
            this.e1.Name = "e1";
            this.e1.Size = new System.Drawing.Size(64, 64);
            this.e1.TabIndex = 49;
            this.e1.TabStop = false;
            this.e1.Text = ";";
            this.e1.UseVisualStyleBackColor = false;
            this.e1.Click += new System.EventHandler(this.BtnClick);
            // 
            // d10
            // 
            this.d10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.d10.BackColor = System.Drawing.SystemColors.Control;
            this.d10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.d10.Font = new System.Drawing.Font("Arial Rounded MT Bold", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.d10.Location = new System.Drawing.Point(711, 293);
            this.d10.Name = "d10";
            this.d10.Size = new System.Drawing.Size(64, 64);
            this.d10.TabIndex = 50;
            this.d10.TabStop = false;
            this.d10.Text = "_";
            this.d10.UseVisualStyleBackColor = false;
            this.d10.Click += new System.EventHandler(this.BtnClick);
            // 
            // e10
            // 
            this.e10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.e10.BackColor = System.Drawing.SystemColors.Control;
            this.e10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.e10.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.e10.Location = new System.Drawing.Point(661, 375);
            this.e10.Name = "e10";
            this.e10.Size = new System.Drawing.Size(64, 64);
            this.e10.TabIndex = 52;
            this.e10.TabStop = false;
            this.e10.Text = ",";
            this.e10.UseVisualStyleBackColor = false;
            this.e10.Click += new System.EventHandler(this.BtnClick);
            // 
            // b6
            // 
            this.b6.BackColor = System.Drawing.SystemColors.Control;
            this.b6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b6.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b6.Location = new System.Drawing.Point(385, 82);
            this.b6.Name = "b6";
            this.b6.Size = new System.Drawing.Size(64, 64);
            this.b6.TabIndex = 62;
            this.b6.TabStop = false;
            this.b6.Text = "s6";
            this.b6.UseVisualStyleBackColor = false;
            this.b6.Click += new System.EventHandler(this.BtnClick);
            // 
            // b5
            // 
            this.b5.BackColor = System.Drawing.SystemColors.Control;
            this.b5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b5.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b5.Location = new System.Drawing.Point(311, 82);
            this.b5.Name = "b5";
            this.b5.Size = new System.Drawing.Size(64, 64);
            this.b5.TabIndex = 61;
            this.b5.TabStop = false;
            this.b5.Text = "s5";
            this.b5.UseVisualStyleBackColor = false;
            this.b5.Click += new System.EventHandler(this.BtnClick);
            // 
            // b4
            // 
            this.b4.BackColor = System.Drawing.SystemColors.Control;
            this.b4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b4.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b4.Location = new System.Drawing.Point(237, 82);
            this.b4.Name = "b4";
            this.b4.Size = new System.Drawing.Size(64, 64);
            this.b4.TabIndex = 60;
            this.b4.TabStop = false;
            this.b4.Text = "s4";
            this.b4.UseVisualStyleBackColor = false;
            this.b4.Click += new System.EventHandler(this.BtnClick);
            // 
            // b3
            // 
            this.b3.BackColor = System.Drawing.SystemColors.Control;
            this.b3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b3.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b3.Location = new System.Drawing.Point(163, 82);
            this.b3.Name = "b3";
            this.b3.Size = new System.Drawing.Size(64, 64);
            this.b3.TabIndex = 59;
            this.b3.TabStop = false;
            this.b3.Text = "s3";
            this.b3.UseVisualStyleBackColor = false;
            this.b3.Click += new System.EventHandler(this.BtnClick);
            // 
            // b2
            // 
            this.b2.BackColor = System.Drawing.SystemColors.Control;
            this.b2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b2.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b2.Location = new System.Drawing.Point(89, 82);
            this.b2.Name = "b2";
            this.b2.Size = new System.Drawing.Size(64, 64);
            this.b2.TabIndex = 58;
            this.b2.TabStop = false;
            this.b2.Text = "s2";
            this.b2.UseVisualStyleBackColor = false;
            this.b2.Click += new System.EventHandler(this.BtnClick);
            // 
            // b1
            // 
            this.b1.BackColor = System.Drawing.SystemColors.Control;
            this.b1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b1.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b1.Location = new System.Drawing.Point(15, 82);
            this.b1.Name = "b1";
            this.b1.Size = new System.Drawing.Size(64, 64);
            this.b1.TabIndex = 57;
            this.b1.TabStop = false;
            this.b1.Text = "s1";
            this.b1.UseVisualStyleBackColor = false;
            this.b1.Click += new System.EventHandler(this.BtnClick);
            // 
            // b10
            // 
            this.b10.BackColor = System.Drawing.SystemColors.Control;
            this.b10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b10.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b10.Location = new System.Drawing.Point(681, 82);
            this.b10.Name = "b10";
            this.b10.Size = new System.Drawing.Size(64, 64);
            this.b10.TabIndex = 56;
            this.b10.TabStop = false;
            this.b10.Text = "t.";
            this.b10.UseVisualStyleBackColor = false;
            this.b10.Click += new System.EventHandler(this.BtnClick);
            // 
            // b9
            // 
            this.b9.BackColor = System.Drawing.SystemColors.Control;
            this.b9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b9.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b9.Location = new System.Drawing.Point(607, 82);
            this.b9.Name = "b9";
            this.b9.Size = new System.Drawing.Size(64, 64);
            this.b9.TabIndex = 55;
            this.b9.TabStop = false;
            this.b9.Text = "s9";
            this.b9.UseVisualStyleBackColor = false;
            this.b9.Click += new System.EventHandler(this.BtnClick);
            // 
            // b8
            // 
            this.b8.BackColor = System.Drawing.SystemColors.Control;
            this.b8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b8.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b8.Location = new System.Drawing.Point(533, 82);
            this.b8.Name = "b8";
            this.b8.Size = new System.Drawing.Size(64, 64);
            this.b8.TabIndex = 54;
            this.b8.TabStop = false;
            this.b8.Text = "s8";
            this.b8.UseVisualStyleBackColor = false;
            this.b8.Click += new System.EventHandler(this.BtnClick);
            // 
            // b7
            // 
            this.b7.BackColor = System.Drawing.SystemColors.Control;
            this.b7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b7.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b7.Location = new System.Drawing.Point(459, 82);
            this.b7.Name = "b7";
            this.b7.Size = new System.Drawing.Size(64, 64);
            this.b7.TabIndex = 53;
            this.b7.TabStop = false;
            this.b7.Text = "s7";
            this.b7.UseVisualStyleBackColor = false;
            this.b7.Click += new System.EventHandler(this.BtnClick);
            // 
            // b11
            // 
            this.b11.BackColor = System.Drawing.SystemColors.Control;
            this.b11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b11.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b11.Location = new System.Drawing.Point(755, 82);
            this.b11.Name = "b11";
            this.b11.Size = new System.Drawing.Size(64, 64);
            this.b11.TabIndex = 65;
            this.b11.TabStop = false;
            this.b11.Text = "e.";
            this.b11.UseVisualStyleBackColor = false;
            this.b11.Click += new System.EventHandler(this.BtnClick);
            // 
            // e12
            // 
            this.e12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.e12.BackColor = System.Drawing.SystemColors.Control;
            this.e12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.e12.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.e12.Location = new System.Drawing.Point(813, 374);
            this.e12.Name = "e12";
            this.e12.Size = new System.Drawing.Size(64, 64);
            this.e12.TabIndex = 64;
            this.e12.TabStop = false;
            this.e12.Text = "u.";
            this.e12.UseVisualStyleBackColor = false;
            this.e12.Click += new System.EventHandler(this.BtnClick);
            // 
            // a11
            // 
            this.a11.BackColor = System.Drawing.SystemColors.Control;
            this.a11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.a11.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a11.Location = new System.Drawing.Point(734, 1);
            this.a11.Name = "a11";
            this.a11.Size = new System.Drawing.Size(64, 64);
            this.a11.TabIndex = 63;
            this.a11.TabStop = false;
            this.a11.Text = "y.";
            this.a11.UseVisualStyleBackColor = false;
            this.a11.Click += new System.EventHandler(this.BtnClick);
            // 
            // e2
            // 
            this.e2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.e2.BackColor = System.Drawing.SystemColors.Control;
            this.e2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.e2.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.e2.Location = new System.Drawing.Point(77, 375);
            this.e2.Name = "e2";
            this.e2.Size = new System.Drawing.Size(64, 64);
            this.e2.TabIndex = 66;
            this.e2.TabStop = false;
            this.e2.Text = "=";
            this.e2.UseVisualStyleBackColor = false;
            this.e2.Click += new System.EventHandler(this.BtnClick);
            // 
            // btnApos
            // 
            this.btnApos.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnApos.BackColor = System.Drawing.SystemColors.Control;
            this.btnApos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnApos.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnApos.Location = new System.Drawing.Point(218, 457);
            this.btnApos.Name = "btnApos";
            this.btnApos.Size = new System.Drawing.Size(64, 63);
            this.btnApos.TabIndex = 67;
            this.btnApos.TabStop = false;
            this.btnApos.Text = "\'";
            this.btnApos.UseVisualStyleBackColor = false;
            this.btnApos.Click += new System.EventHandler(this.BtnClick);
            // 
            // c11
            // 
            this.c11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.c11.BackColor = System.Drawing.SystemColors.Control;
            this.c11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c11.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c11.Location = new System.Drawing.Point(766, 212);
            this.c11.Name = "c11";
            this.c11.Size = new System.Drawing.Size(64, 64);
            this.c11.TabIndex = 68;
            this.c11.TabStop = false;
            this.c11.Text = "e.";
            this.c11.UseVisualStyleBackColor = false;
            this.c11.Click += new System.EventHandler(this.BtnClick);
            // 
            // c12
            // 
            this.c12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.c12.BackColor = System.Drawing.SystemColors.Control;
            this.c12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.c12.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c12.Location = new System.Drawing.Point(839, 212);
            this.c12.Name = "c12";
            this.c12.Size = new System.Drawing.Size(64, 64);
            this.c12.TabIndex = 69;
            this.c12.TabStop = false;
            this.c12.Text = "e.";
            this.c12.UseVisualStyleBackColor = false;
            this.c12.Click += new System.EventHandler(this.BtnClick);
            // 
            // b12
            // 
            this.b12.BackColor = System.Drawing.SystemColors.Control;
            this.b12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b12.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b12.Location = new System.Drawing.Point(829, 82);
            this.b12.Name = "b12";
            this.b12.Size = new System.Drawing.Size(64, 64);
            this.b12.TabIndex = 70;
            this.b12.TabStop = false;
            this.b12.Text = "e.";
            this.b12.UseVisualStyleBackColor = false;
            this.b12.Click += new System.EventHandler(this.BtnClick);
            // 
            // d11
            // 
            this.d11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.d11.BackColor = System.Drawing.SystemColors.Control;
            this.d11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.d11.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.d11.Location = new System.Drawing.Point(785, 293);
            this.d11.Name = "d11";
            this.d11.Size = new System.Drawing.Size(64, 64);
            this.d11.TabIndex = 71;
            this.d11.TabStop = false;
            this.d11.Text = "e.";
            this.d11.UseVisualStyleBackColor = false;
            this.d11.Click += new System.EventHandler(this.BtnClick);
            // 
            // d12
            // 
            this.d12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.d12.BackColor = System.Drawing.SystemColors.Control;
            this.d12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.d12.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.d12.Location = new System.Drawing.Point(859, 293);
            this.d12.Name = "d12";
            this.d12.Size = new System.Drawing.Size(64, 64);
            this.d12.TabIndex = 72;
            this.d12.TabStop = false;
            this.d12.Text = "e.";
            this.d12.UseVisualStyleBackColor = false;
            this.d12.Click += new System.EventHandler(this.BtnClick);
            // 
            // Keyboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.Controls.Add(this.d12);
            this.Controls.Add(this.d11);
            this.Controls.Add(this.b12);
            this.Controls.Add(this.c12);
            this.Controls.Add(this.c11);
            this.Controls.Add(this.btnApos);
            this.Controls.Add(this.e2);
            this.Controls.Add(this.b11);
            this.Controls.Add(this.e12);
            this.Controls.Add(this.a11);
            this.Controls.Add(this.b6);
            this.Controls.Add(this.b5);
            this.Controls.Add(this.b4);
            this.Controls.Add(this.b3);
            this.Controls.Add(this.b2);
            this.Controls.Add(this.b1);
            this.Controls.Add(this.b10);
            this.Controls.Add(this.b9);
            this.Controls.Add(this.b8);
            this.Controls.Add(this.b7);
            this.Controls.Add(this.e10);
            this.Controls.Add(this.d10);
            this.Controls.Add(this.e1);
            this.Controls.Add(this.e11);
            this.Controls.Add(this.chk_shift);
            this.Controls.Add(this.btn_backspace);
            this.Controls.Add(this.btn_OK);
            this.Controls.Add(this.btn_cancel);
            this.Controls.Add(this.c6);
            this.Controls.Add(this.c5);
            this.Controls.Add(this.c4);
            this.Controls.Add(this.c3);
            this.Controls.Add(this.c2);
            this.Controls.Add(this.a6);
            this.Controls.Add(this.a5);
            this.Controls.Add(this.a10);
            this.Controls.Add(this.c1);
            this.Controls.Add(this.a7);
            this.Controls.Add(this.a9);
            this.Controls.Add(this.a8);
            this.Controls.Add(this.a4);
            this.Controls.Add(this.a2);
            this.Controls.Add(this.a1);
            this.Controls.Add(this.btn_clear);
            this.Controls.Add(this.btn_space);
            this.Controls.Add(this.e9);
            this.Controls.Add(this.e8);
            this.Controls.Add(this.e7);
            this.Controls.Add(this.e6);
            this.Controls.Add(this.e5);
            this.Controls.Add(this.e4);
            this.Controls.Add(this.e3);
            this.Controls.Add(this.d9);
            this.Controls.Add(this.d8);
            this.Controls.Add(this.d7);
            this.Controls.Add(this.d6);
            this.Controls.Add(this.d5);
            this.Controls.Add(this.d4);
            this.Controls.Add(this.d3);
            this.Controls.Add(this.d2);
            this.Controls.Add(this.d1);
            this.Controls.Add(this.c10);
            this.Controls.Add(this.c9);
            this.Controls.Add(this.c8);
            this.Controls.Add(this.c7);
            this.Controls.Add(this.a3);
            this.Name = "Keyboard";
            this.Size = new System.Drawing.Size(925, 525);
            this.Load += new System.EventHandler(this.Keyboard_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button a3;
        private System.Windows.Forms.Button c7;
        private System.Windows.Forms.Button c8;
        private System.Windows.Forms.Button c9;
        private System.Windows.Forms.Button c10;
        private System.Windows.Forms.Button d1;
        private System.Windows.Forms.Button d2;
        private System.Windows.Forms.Button d3;
        private System.Windows.Forms.Button d4;
        private System.Windows.Forms.Button d5;
        private System.Windows.Forms.Button d6;
        private System.Windows.Forms.Button d7;
        private System.Windows.Forms.Button d8;
        private System.Windows.Forms.Button d9;
        private System.Windows.Forms.Button e3;
        private System.Windows.Forms.Button e4;
        private System.Windows.Forms.Button e5;
        private System.Windows.Forms.Button e6;
        private System.Windows.Forms.Button e7;
        private System.Windows.Forms.Button e8;
        private System.Windows.Forms.Button e9;
        private System.Windows.Forms.Button btn_space;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.Button a1;
        private System.Windows.Forms.Button a2;
        private System.Windows.Forms.Button a4;
        private System.Windows.Forms.Button a8;
        private System.Windows.Forms.Button a9;
        private System.Windows.Forms.Button a7;
        private System.Windows.Forms.Button c1;
        private System.Windows.Forms.Button a10;
        private System.Windows.Forms.Button a5;
        private System.Windows.Forms.Button a6;
        private System.Windows.Forms.Button c2;
        private System.Windows.Forms.Button c3;
        private System.Windows.Forms.Button c4;
        private System.Windows.Forms.Button c5;
        private System.Windows.Forms.Button c6;
        private System.Windows.Forms.Button btn_cancel;
        private System.Windows.Forms.Button btn_OK;
        private System.Windows.Forms.Button btn_backspace;
        private System.Windows.Forms.CheckBox chk_shift;
        private System.Windows.Forms.Button e11;
        private System.Windows.Forms.Button e1;
        private System.Windows.Forms.Button d10;
        private System.Windows.Forms.Button e10;
        private System.Windows.Forms.Button b6;
        private System.Windows.Forms.Button b5;
        private System.Windows.Forms.Button b4;
        private System.Windows.Forms.Button b3;
        private System.Windows.Forms.Button b2;
        private System.Windows.Forms.Button b1;
        private System.Windows.Forms.Button b10;
        private System.Windows.Forms.Button b9;
        private System.Windows.Forms.Button b8;
        private System.Windows.Forms.Button b7;
        private System.Windows.Forms.Button b11;
        private System.Windows.Forms.Button e12;
        private System.Windows.Forms.Button a11;
        private System.Windows.Forms.Button e2;
        private System.Windows.Forms.Button btnApos;
        private System.Windows.Forms.Button c11;
        private System.Windows.Forms.Button c12;
        private System.Windows.Forms.Button b12;
        private System.Windows.Forms.Button d11;
        private System.Windows.Forms.Button d12;
    }
}
